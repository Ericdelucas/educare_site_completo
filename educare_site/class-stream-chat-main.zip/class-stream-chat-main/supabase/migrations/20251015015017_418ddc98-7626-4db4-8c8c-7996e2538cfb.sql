-- Criar tabela para salas de videoconferência
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_code TEXT NOT NULL UNIQUE,
  host_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Criar tabela para mensagens de chat
CREATE TABLE public.messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  sender_name TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela para sinalização WebRTC
CREATE TABLE public.webrtc_signals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  peer_id TEXT NOT NULL,
  signal_type TEXT NOT NULL,
  signal_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS nas tabelas
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webrtc_signals ENABLE ROW LEVEL SECURITY;

-- Políticas para rooms (público pode ler e criar)
CREATE POLICY "Todos podem ver salas ativas"
  ON public.rooms FOR SELECT
  USING (is_active = true);

CREATE POLICY "Qualquer um pode criar uma sala"
  ON public.rooms FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Host pode atualizar sua sala"
  ON public.rooms FOR UPDATE
  USING (true);

-- Políticas para mensagens (público pode ler e criar)
CREATE POLICY "Todos podem ver mensagens"
  ON public.messages FOR SELECT
  USING (true);

CREATE POLICY "Qualquer um pode enviar mensagens"
  ON public.messages FOR INSERT
  WITH CHECK (true);

-- Políticas para sinais WebRTC
CREATE POLICY "Todos podem ver sinais"
  ON public.webrtc_signals FOR SELECT
  USING (true);

CREATE POLICY "Qualquer um pode enviar sinais"
  ON public.webrtc_signals FOR INSERT
  WITH CHECK (true);

-- Habilitar realtime para as tabelas
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.webrtc_signals;
ALTER PUBLICATION supabase_realtime ADD TABLE public.rooms;