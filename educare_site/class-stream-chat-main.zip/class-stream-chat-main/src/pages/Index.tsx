import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Video, Users, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Index = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [userName, setUserName] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [isJoining, setIsJoining] = useState(false);

  const generateRoomCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const createRoom = async () => {
    if (!userName.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira seu nome",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);

    try {
      const code = generateRoomCode();
      
      const { data, error } = await supabase
        .from('rooms')
        .insert({
          room_code: code,
          host_name: userName,
        })
        .select()
        .single();

      if (error) throw error;

      sessionStorage.setItem('userName', userName);
      toast({
        title: "Sala criada!",
        description: `Código da sala: ${code}`,
      });
      
      navigate(`/room/${code}`);
    } catch (error) {
      console.error('Erro ao criar sala:', error);
      toast({
        title: "Erro",
        description: "Não foi possível criar a sala",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const joinRoom = async () => {
    if (!userName.trim() || !roomCode.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }

    setIsJoining(true);

    try {
      const { data, error } = await supabase
        .from('rooms')
        .select('*')
        .eq('room_code', roomCode.toUpperCase())
        .eq('is_active', true)
        .single();

      if (error || !data) {
        toast({
          title: "Erro",
          description: "Sala não encontrada ou inativa",
          variant: "destructive",
        });
        return;
      }

      sessionStorage.setItem('userName', userName);
      navigate(`/room/${roomCode.toUpperCase()}`);
    } catch (error) {
      console.error('Erro ao entrar na sala:', error);
      toast({
        title: "Erro",
        description: "Não foi possível entrar na sala",
        variant: "destructive",
      });
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-primary to-secondary mb-6 shadow-lg shadow-primary/30">
            <Video className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent animate-pulse">
            EduStream
          </h1>
          <p className="text-xl text-muted-foreground mb-2">
            Plataforma profissional de videoaulas ao vivo
          </p>
          <p className="text-sm text-muted-foreground">
            Conecte-se com qualidade e simplicidade
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="p-6 text-center border-border bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
              <Video className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Vídeo em HD</h3>
            <p className="text-sm text-muted-foreground">
              Qualidade profissional para suas aulas
            </p>
          </Card>
          
          <Card className="p-6 text-center border-border bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-secondary/10">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-secondary/10 mb-4">
              <Users className="w-6 h-6 text-secondary" />
            </div>
            <h3 className="font-semibold mb-2">Chat Integrado</h3>
            <p className="text-sm text-muted-foreground">
              Interaja em tempo real com os alunos
            </p>
          </Card>
          
          <Card className="p-6 text-center border-border bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-4">
              <BookOpen className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-semibold mb-2">Fácil de Usar</h3>
            <p className="text-sm text-muted-foreground">
              Sem complicação, apenas ensinar
            </p>
          </Card>
        </div>

        {/* Main Action Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Criar Sala */}
          <Card className="p-8 border-border bg-card/80 backdrop-blur-sm shadow-xl">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Video className="w-5 h-5 text-white" />
              </div>
              Criar Nova Sala
            </h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Seu nome
                </label>
                <Input
                  placeholder="Professor Silva"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="bg-background border-border"
                />
              </div>
              <Button
                onClick={createRoom}
                disabled={isCreating}
                className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-white font-semibold py-6 text-lg shadow-lg shadow-primary/30"
              >
                {isCreating ? "Criando..." : "Criar Sala de Aula"}
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Um código único será gerado para compartilhar com seus alunos
              </p>
            </div>
          </Card>

          {/* Entrar na Sala */}
          <Card className="p-8 border-border bg-card/80 backdrop-blur-sm shadow-xl">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-secondary to-primary flex items-center justify-center">
                <Users className="w-5 h-5 text-white" />
              </div>
              Entrar em uma Sala
            </h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Seu nome
                </label>
                <Input
                  placeholder="Aluno João"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="bg-background border-border"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Código da sala
                </label>
                <Input
                  placeholder="ABC123"
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  className="bg-background border-border font-mono text-lg tracking-wider"
                  maxLength={6}
                />
              </div>
              <Button
                onClick={joinRoom}
                disabled={isJoining}
                variant="outline"
                className="w-full border-2 border-primary hover:bg-primary hover:text-primary-foreground font-semibold py-6 text-lg"
              >
                {isJoining ? "Entrando..." : "Entrar na Aula"}
              </Button>
            </div>
          </Card>
        </div>

        {/* Footer Info */}
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground">
            Funciona em qualquer dispositivo • Sem necessidade de download • Totalmente gratuito
          </p>
        </div>
      </div>
    </div>
  );
};

export default Index;