import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Video, VideoOff, Mic, MicOff, Phone, MessageSquare, Users, Hand } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { RealtimeChannel } from "@supabase/supabase-js";

interface Message {
  id: string;
  sender_name: string;
  message: string;
  created_at: string;
}

const VideoCall = () => {
  const { roomCode } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [showChat, setShowChat] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [userName] = useState(() => sessionStorage.getItem('userName') || 'Participante');
  const [roomId, setRoomId] = useState<string | null>(null);
  const [participantCount, setParticipantCount] = useState(1);
  const [handRaised, setHandRaised] = useState(false);
  const [raisedHands, setRaisedHands] = useState<string[]>([]);
  const [isHost, setIsHost] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    initializeCall();
    return () => cleanup();
  }, []);

  const initializeCall = async () => {
    try {
      console.log('🚀 Iniciando chamada para sala:', roomCode);
      
      // Obter sala do banco de dados
      const { data: room } = await supabase
        .from('rooms')
        .select('id, host_name')
        .eq('room_code', roomCode)
        .single();

      if (!room) {
        toast({
          title: "Erro",
          description: "Sala não encontrada",
          variant: "destructive",
        });
        navigate('/');
        return;
      }

      const userIsHost = room.host_name === userName;
      setIsHost(userIsHost);
      setRoomId(room.id);
      
      console.log('👤 Usuário:', userName, '| Host:', userIsHost);

      // Iniciar stream local
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      
      setLocalStream(stream);
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Configurar WebRTC
      setupPeerConnection(stream);

      // Configurar realtime
      setupRealtimeChannels(room.id);

      // Carregar mensagens existentes
      loadMessages(room.id);
      
      // Host cria offer automaticamente após 2 segundos
      if (userIsHost) {
        console.log('🎯 Host detectado - criará offer em 2s');
        setTimeout(() => {
          console.log('📤 Host criando offer...');
          createOffer();
        }, 2000);
      } else {
        console.log('👥 Participante aguardando offer do host');
      }

    } catch (error) {
      console.error('❌ Erro ao inicializar chamada:', error);
      toast({
        title: "Erro",
        description: "Não foi possível acessar câmera/microfone",
        variant: "destructive",
      });
    }
  };

  const setupPeerConnection = (stream: MediaStream) => {
    const configuration = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
      ],
    };

    peerConnection.current = new RTCPeerConnection(configuration);

    // Adicionar tracks locais
    stream.getTracks().forEach(track => {
      peerConnection.current?.addTrack(track, stream);
    });

    // Receber tracks remotos
    peerConnection.current.ontrack = (event) => {
      console.log('📹 Track remoto recebido!', event.streams[0]);
      const stream = event.streams[0];
      setRemoteStream(stream);
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = stream;
      }
      setIsConnecting(false);
      toast({
        title: "✅ Conectado",
        description: "Vídeo do participante recebido",
      });
    };

    // ICE candidates
    peerConnection.current.onicecandidate = async (event) => {
      if (event.candidate && roomId) {
        console.log('🧊 Enviando ICE candidate');
        await supabase.from('webrtc_signals').insert({
          room_id: roomId!,
          peer_id: userName,
          signal_type: 'ice-candidate',
          signal_data: event.candidate as any,
        });
      }
    };

    peerConnection.current.onconnectionstatechange = () => {
      const state = peerConnection.current?.connectionState;
      console.log('🔗 Estado da conexão:', state);
      
      if (state === 'connected') {
        setIsConnecting(false);
        console.log('✅ WebRTC conectado!');
      } else if (state === 'failed' || state === 'disconnected') {
        console.log('❌ Conexão falhou ou desconectou');
        setIsConnecting(false);
      }
    };
  };

  const setupRealtimeChannels = (roomId: string) => {
    // Canal para mensagens
    const messagesChannel = supabase
      .channel(`messages:${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `room_id=eq.${roomId}`,
        },
        (payload) => {
          setMessages(prev => [...prev, payload.new as Message]);
        }
      )
      .subscribe();

    // Canal para sinais WebRTC
    const signalsChannel = supabase
      .channel(`signals:${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'webrtc_signals',
          filter: `room_id=eq.${roomId}`,
        },
        async (payload: any) => {
          const signal = payload.new;
          if (signal.peer_id !== userName) {
            await handleSignal(signal);
          }
        }
      )
      .subscribe();

    // Canal de presença
    const presenceChannel = supabase.channel(`presence:${roomId}`, {
      config: { presence: { key: userName } }
    });

    presenceChannel
      .on('presence', { event: 'sync' }, () => {
        const state = presenceChannel.presenceState();
        setParticipantCount(Object.keys(state).length);
        
        // Atualizar lista de mãos levantadas
        const handsUp: string[] = [];
        Object.values(state).forEach((presences: any) => {
          presences.forEach((presence: any) => {
            if (presence.hand_raised) {
              handsUp.push(presence.user);
            }
          });
        });
        setRaisedHands(handsUp);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await presenceChannel.track({ 
            user: userName, 
            online_at: new Date().toISOString(),
            hand_raised: false 
          });
        }
      });

    channelRef.current = presenceChannel;
  };

  const handleSignal = async (signal: any) => {
    if (!peerConnection.current) return;

    try {
      if (signal.signal_type === 'offer') {
        console.log('📥 Recebendo OFFER');
        setIsConnecting(true);
        await peerConnection.current.setRemoteDescription(
          new RTCSessionDescription(signal.signal_data)
        );
        console.log('📤 Criando ANSWER');
        const answer = await peerConnection.current.createAnswer();
        await peerConnection.current.setLocalDescription(answer);
        
        await supabase.from('webrtc_signals').insert({
          room_id: roomId!,
          peer_id: userName,
          signal_type: 'answer',
          signal_data: answer as any,
        });
        console.log('✅ ANSWER enviado');
      } else if (signal.signal_type === 'answer') {
        console.log('📥 Recebendo ANSWER');
        await peerConnection.current.setRemoteDescription(
          new RTCSessionDescription(signal.signal_data)
        );
        console.log('✅ Remote description configurada');
      } else if (signal.signal_type === 'ice-candidate') {
        console.log('📥 Recebendo ICE candidate');
        await peerConnection.current.addIceCandidate(
          new RTCIceCandidate(signal.signal_data)
        );
      }
    } catch (error) {
      console.error('❌ Erro ao processar sinal:', error);
      setIsConnecting(false);
    }
  };

  const createOffer = async () => {
    if (!peerConnection.current || !roomId) return;

    try {
      console.log('📤 Criando OFFER');
      setIsConnecting(true);
      const offer = await peerConnection.current.createOffer();
      await peerConnection.current.setLocalDescription(offer);
      
      await supabase.from('webrtc_signals').insert({
        room_id: roomId!,
        peer_id: userName,
        signal_type: 'offer',
        signal_data: offer as any,
      });
      console.log('✅ OFFER enviado');
      
      toast({
        title: "Conectando...",
        description: "Aguardando participante aceitar",
      });
    } catch (error) {
      console.error('❌ Erro ao criar oferta:', error);
      setIsConnecting(false);
      toast({
        title: "Erro",
        description: "Falha ao conectar",
        variant: "destructive",
      });
    }
  };

  const loadMessages = async (roomId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('room_id', roomId)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !roomId) return;

    await supabase.from('messages').insert({
      room_id: roomId,
      sender_name: userName,
      message: newMessage,
    });

    setNewMessage('');
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoEnabled(!isVideoEnabled);
    }
  };

  const toggleAudio = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsAudioEnabled(!isAudioEnabled);
    }
  };

  const toggleHandRaise = async () => {
    const newHandRaisedState = !handRaised;
    setHandRaised(newHandRaisedState);
    
    if (channelRef.current) {
      await channelRef.current.track({ 
        user: userName, 
        online_at: new Date().toISOString(),
        hand_raised: newHandRaisedState 
      });
    }

    toast({
      title: newHandRaisedState ? "Mão levantada" : "Mão abaixada",
      description: newHandRaisedState ? "O professor verá que você levantou a mão" : "Você abaixou a mão",
    });
  };

  const endCall = () => {
    cleanup();
    navigate('/');
  };

  const cleanup = () => {
    localStream?.getTracks().forEach(track => track.stop());
    peerConnection.current?.close();
    channelRef.current?.unsubscribe();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Sala: {roomCode}
            </h1>
            <div className="flex items-center gap-4 text-muted-foreground mt-1">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span>{participantCount} participante{participantCount !== 1 ? 's' : ''}</span>
              </div>
              {raisedHands.length > 0 && (
                <div className="flex items-center gap-2 text-secondary">
                  <Hand className="w-4 h-4" />
                  <span>{raisedHands.length} mão{raisedHands.length !== 1 ? 's' : ''} levantada{raisedHands.length !== 1 ? 's' : ''}</span>
                </div>
              )}
            </div>
          </div>
          {isConnecting && (
            <div className="text-secondary animate-pulse">
              Conectando...
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Área de vídeo */}
          <div className="lg:col-span-2 space-y-4">
            {/* Vídeo remoto (principal) */}
            <Card className="relative overflow-hidden bg-card border-border aspect-video">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              {!remoteStream && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted/50 backdrop-blur-sm">
                  <div className="text-center">
                    <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">
                      {isConnecting ? 'Conectando...' : 'Aguardando participante...'}
                    </p>
                    {isHost && !isConnecting && participantCount === 1 && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Compartilhe o código da sala com os alunos
                      </p>
                    )}
                  </div>
                </div>
              )}
            </Card>

            {/* Vídeo local (miniatura) */}
            <Card className="relative overflow-hidden bg-card border-border aspect-video max-w-xs">
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover"
              />
              {!isVideoEnabled && (
                <div className="absolute inset-0 flex items-center justify-center bg-background/80">
                  <VideoOff className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
              <div className="absolute bottom-2 left-2 bg-background/80 px-2 py-1 rounded text-sm">
                Você
              </div>
            </Card>

            {/* Controles */}
            <div className="flex justify-center gap-4">
              <Button
                size="lg"
                variant={isVideoEnabled ? "default" : "destructive"}
                onClick={toggleVideo}
                className="rounded-full w-14 h-14"
              >
                {isVideoEnabled ? <Video /> : <VideoOff />}
              </Button>
              <Button
                size="lg"
                variant={isAudioEnabled ? "default" : "destructive"}
                onClick={toggleAudio}
                className="rounded-full w-14 h-14"
              >
                {isAudioEnabled ? <Mic /> : <MicOff />}
              </Button>
              <Button
                size="lg"
                variant={handRaised ? "secondary" : "outline"}
                onClick={toggleHandRaise}
                className="rounded-full w-14 h-14"
                title="Levantar mão"
              >
                <Hand className={handRaised ? "animate-bounce" : ""} />
              </Button>
              <Button
                size="lg"
                variant="destructive"
                onClick={endCall}
                className="rounded-full w-14 h-14"
              >
                <Phone className="rotate-135" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setShowChat(!showChat)}
                className="rounded-full w-14 h-14 lg:hidden"
              >
                <MessageSquare />
              </Button>
            </div>
          </div>

          {/* Chat */}
          {(showChat || window.innerWidth >= 1024) && (
            <Card className="p-4 flex flex-col h-[600px] bg-card border-border">
              <div className="mb-4 pb-4 border-b border-border space-y-3">
                <h2 className="font-semibold flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Chat
                </h2>
                
                {/* Lista de mãos levantadas */}
                {raisedHands.length > 0 && (
                  <div className="bg-secondary/20 border border-secondary/30 rounded-lg p-2">
                    <div className="flex items-center gap-2 text-sm text-secondary font-medium mb-1">
                      <Hand className="w-4 h-4" />
                      Mãos levantadas:
                    </div>
                    <div className="text-xs space-y-1">
                      {raisedHands.map((name, index) => (
                        <div key={index} className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 bg-secondary rounded-full"></span>
                          <span>{name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex-1 overflow-y-auto space-y-3 mb-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`p-3 rounded-lg ${
                      msg.sender_name === userName
                        ? 'bg-primary text-primary-foreground ml-auto'
                        : 'bg-muted'
                    } max-w-[80%] ${msg.sender_name === userName ? 'ml-auto' : ''}`}
                  >
                    <p className="text-xs opacity-70 mb-1">{msg.sender_name}</p>
                    <p className="text-sm break-words">{msg.message}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  placeholder="Digite sua mensagem..."
                  className="bg-background border-border"
                />
                <Button onClick={sendMessage} className="bg-primary hover:bg-primary/90">
                  Enviar
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoCall;